TASK_TYPE = 'text-generation'

# Dataset name

# pre-trained model name
PRETRAINED_MODEL_NAME = 'gpt2'

# List of the class values (labels) in a classification dataset.


# maximum sequence length
MAX_SEQ_LENGTH = 512
